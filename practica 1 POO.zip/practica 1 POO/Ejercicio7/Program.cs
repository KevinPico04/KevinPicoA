﻿internal class Program
{
    private static void Main(string[] args)
    {
        string Activador="S";
        while (Activador == "S"){
            if (Activador =="S"){
                double dato1;
                double dato2;
                double dato3;
                Console.WriteLine("Ingrese un numero");
                dato1=Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Ingrese un numero");
                dato2=Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Ingrese un numero");
                dato3=Convert.ToDouble(Console.ReadLine());
                if (dato1==dato2 && dato1==dato3){
                    Console.WriteLine("Los tres numeros ingresados forman un triangulo equilatero");
                }
                else {
                    if (dato1==dato2 || dato2==dato3 || dato1==dato3){
                        Console.WriteLine("Los tres numeros ingresados forman un triangulo isosceles");
                    }
                    else {
                        Console.WriteLine("Los tres numeros ingresados forman un triangulo escaleno");
                    }
                }
                Console.WriteLine("¿Desea continuar?? Ingrese S para continuar o N para finalizar");
                Activador = Console.ReadLine();
                if (Activador=="N"){
                    Console.WriteLine("Programa finalizado");
                }
            }
        }
    }
}