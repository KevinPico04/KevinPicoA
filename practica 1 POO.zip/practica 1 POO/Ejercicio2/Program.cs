﻿internal class Program
{
    private static void Main(string[] args)
    {
        int Numero;
        Console.WriteLine("Ingrese un numero");
        Numero=Convert.ToInt32(Console.ReadLine());
        if (Numero % 2 ==0){
            Console.WriteLine("Su numero "+Numero+ " es par");
        }
        else {
            Console.WriteLine("SU numero "+Numero+ " es impar");
        }
    }
}