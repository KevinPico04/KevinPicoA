﻿internal class Program
{
    private static void Main(string[] args)
    {
        double suma=0;
        double dato;
        double Activador=1;
        while (Activador!=0){
            Console.WriteLine("Ingrese un numero, si ingresa el 0 el programa terminará");
            dato=Convert.ToInt32(Console.ReadLine());
            suma+=dato;
            Activador=dato;
            if (Activador==0){
                Console.WriteLine("La suma total de todos los numeros que ingresó es "+suma);
                Console.WriteLine("El programa finalizó");
            }
        }
    }
}