﻿internal class Program
{
    private static void Main(string[] args)
    {
        double dato1, dato2;
        Console.WriteLine("Ingrese un numero");
        dato1=Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Ingrese otro numero");
        dato2=Convert.ToDouble(Console.ReadLine());
        if (dato1>dato2){
            Console.WriteLine("El numero mayor es "+dato1);
        }
        else {
            Console.WriteLine("El numero mayor es "+dato2);
        }
    }
}