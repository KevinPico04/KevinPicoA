﻿internal class Program
{
    private static void Main(string[] args)
    {
        double suma=0;
        double divisor=-1;
        double dato=1;
        double resultado=0;
        while (dato!=0){
            Console.WriteLine("Ingrese un numero, si ingresa el 0 el programa terminará y mostrara la media aritmetica de los numeros ingresados");
            dato=Convert.ToDouble(Console.ReadLine());
            suma+=dato;
            divisor=divisor+1;
            if (dato==0){
                resultado=suma/divisor;
                Console.WriteLine("La media aritmetica de los numero que ingresó es "+resultado);
                Console.WriteLine("Programa finalizado");
            }
        }
    }
}