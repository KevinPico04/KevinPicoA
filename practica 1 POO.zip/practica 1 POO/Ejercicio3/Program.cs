﻿internal class Program
{
    private static void Main(string[] args)
    {
        double dato1, dato2, dato3;
        Console.WriteLine("Ingrese el primer numero");
        dato1=Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Ingrese el segundo numero");
        dato2=Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Ingrese el tercer numero");
        dato3=Convert.ToDouble(Console.ReadLine());
        if (dato1>=dato2){
            if (dato1>=dato3){
                Console.WriteLine("El mayor de los tres numeros es "+dato1);
            }
            else {
                Console.WriteLine("El mayor de los tres numeros es "+dato3);
            }
        }
        else {
            if (dato2>=dato3){
                Console.WriteLine("El mayor de los tres numeros es "+dato2);
            }
            else {
                Console.WriteLine("El mayor de los tres numeros es "+dato3);
            }
        }
    }
}