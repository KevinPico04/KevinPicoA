﻿internal class Program
{
    private static void Main(string[] args)
    {
        for (int cont=1;cont<=3000;++cont){
            int multiplicador=0;
            multiplicador=cont*3;
            Console.WriteLine(multiplicador);
        }
    }
}