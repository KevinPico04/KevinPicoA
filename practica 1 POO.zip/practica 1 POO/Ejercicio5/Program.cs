﻿internal class Program
{
    //Escribir un programa que lea exactamente 8 números y luego escriba la suma de todos ellos
    private static void Main(string[] args)
    {
        double dato;
        double suma=0;
        for (int Contador=0;Contador<8;Contador++){
            
            Console.WriteLine("Ingrese un numero");
            dato = Convert.ToInt32(Console.ReadLine());
            suma+=dato;
            if (Contador==7){
                Console.WriteLine("La suma de los ocho numeros que ingresó es "+suma);
            }
            
        }
    }
}