﻿internal class Program
{
    private static void Main(string[] args)
    {
        int dato=1;
        while (dato !=0){
            Console.WriteLine("Ingrese un numero, si ingresa el numero 0 el programa terminará");
            dato=Convert.ToInt32(Console.ReadLine());
        }
        Console.WriteLine("Programa finalizado");
    }
}