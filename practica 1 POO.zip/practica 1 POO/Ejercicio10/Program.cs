﻿internal class Program
{
    private static void Main(string[] args)
    {
        int dato;
        int factorial=1;
        int cont=0;
        do{
            Console.WriteLine("Ingrese un numero entero");
            dato=Convert.ToInt32(Console.ReadLine());
            if (dato<0){
                Console.WriteLine("Numero ingresado no valido, recuerde que el numero ingresado no debe ser menor a 0");
            }
        } while (dato<0);
        do {
            cont=cont +1;
            factorial*=cont;

        } while (dato>cont);
        Console.WriteLine("El factorial de " +dato+ " es "+factorial);
    }
}